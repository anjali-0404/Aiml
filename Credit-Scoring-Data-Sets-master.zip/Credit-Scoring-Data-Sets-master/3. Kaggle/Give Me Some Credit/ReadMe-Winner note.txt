What was your most important insight into the data?
 
EJ: I discovered 2 key features, the first being the total number of late days, and second the difference between income and expense. They turned out to be very predictive! 


I didn't spend much time on preprocessing. My most important input was to create a variable which estimates the likelihood of being late by more than 90 days.